/* Single source of truth for the app version.
   Run:  python3 bump.py patch|minor|major   (or: python3 bump.py 1.2.3)
   Changing this file changes sw.js's bytes -> installed apps detect the update. */
self.APP_VERSION = '1.0.0';
self.APP_BUILD = '2026-10-20';
