#!/usr/bin/env python3
"""Bump the app version. Usage: python3 bump.py [patch|minor|major|X.Y.Z]
Edits version.js only. Then re-upload the folder to your host."""
import re, sys, datetime, pathlib
p = pathlib.Path(__file__).with_name('version.js')
s = p.read_text()
cur = re.search(r"APP_VERSION = '(\d+)\.(\d+)\.(\d+)'", s)
a, b, c = map(int, cur.groups())
arg = sys.argv[1] if len(sys.argv) > 1 else 'patch'
if arg == 'major': new = f'{a+1}.0.0'
elif arg == 'minor': new = f'{a}.{b+1}.0'
elif arg == 'patch': new = f'{a}.{b}.{c+1}'
elif re.fullmatch(r'\d+\.\d+\.\d+', arg): new = arg
else: sys.exit('Use patch, minor, major or X.Y.Z')
today = datetime.date.today().isoformat()
s = re.sub(r"APP_VERSION = '[^']*'", f"APP_VERSION = '{new}'", s)
s = re.sub(r"APP_BUILD = '[^']*'", f"APP_BUILD = '{today}'", s)
p.write_text(s)
print(f'Version {cur.group(0).split(chr(39))[1]} -> {new} ({today})')
