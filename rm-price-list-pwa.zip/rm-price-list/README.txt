RM Health Meds Price List — installable app (PWA)

HOW TO PUBLISH (needs https — free options: Netlify Drop, GitHub Pages, Cloudflare Pages)
1. Upload this whole folder to your host.
2. Open the web address on the phone/PC:
   - Android/Chrome/Edge: tap "Install App" in the header (or browser menu > Install).
   - iPhone Safari: Share > Add to Home Screen.

HOW TO RELEASE AN UPDATE
1. Edit index.html (new prices, features, etc.).
2. Run:  python3 bump.py patch     (or minor / major / 1.2.3)
   (or just edit the number in version.js by hand)
3. Re-upload the folder.
Installed apps will show "Version X is ready — Update now". One tap and it reloads.

Saved prices/edits stay on each device (localStorage key rm_wholesale_v2) and are kept across updates.
